package Basic;
public class ArrayExample {
    public static void main(String[] args) {
        int[] numbers = { 1, 2, 3, 4, 5 };
        for (int i = 0; i < numbers.length; i++) {
            System.out.println("数组元素 " + i + "：" + numbers[i]);
        }
    }
}
