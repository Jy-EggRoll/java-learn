package Basic;
public class VariableExample {
    public static void main(String[] args) {
        int num1 = 10;
        double num2 = 3.14;
        char letter = 'A';
        boolean isTrue = true;
        String message = "Hello, world!";
        System.out.println(num1);
        System.out.println(num2);
        System.out.println(letter);
        System.out.println(isTrue);
        System.out.println(message);
    }
}
